import styled from 'styled-components';
import logo from '../../assets/images/logo.png'

export const Container = styled.div`
    height: 100vh;
    background: #ee4d64;
    display: flex;
    align-items: center;
    justify-content:center;
`;
export const Box = styled.div`
    width: 400px;
    height: 500px;
    background: #fff;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    border-radius: 4px;
`;
export const Logo = styled.img.attrs({
    src: logo
})`
    width: 100px;
    margin-bottom: 30px;
`;
export const Form = styled.form`
    display: flex;
    flex-direction: column;
`;
